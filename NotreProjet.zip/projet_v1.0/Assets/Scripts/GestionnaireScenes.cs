using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement; // Nécessaire pour gérer les scènes

public class GestionnaireScenes : MonoBehaviour
{
    // Charger une scène par son nom
    public void ChargerScene(string nomScene)
    {
        SoundManager.instance.PlaySFX(EnumSFX.bouton, null); // Jouer le son du bouton
        SceneManager.LoadScene(nomScene); // Charger la scène
    }

    // Quitter le jeu
    public void QuitterJeu()
    {
        Debug.Log("Quitter le jeu...");
        Application.Quit();
    }
}
