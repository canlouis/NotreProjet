using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

public class JoueurConnexion : MonoBehaviour
{
    [SerializeField] float _vitesseRotation = 100f; // Vitesse de rotation ajustable
    [SerializeField] Color[] _couleurs;
    [SerializeField] TextMeshProUGUI _nomJoueur;
    [SerializeField] Image[] _imagesChangerCouleurs;
    [SerializeField] Image _imagePret;
    ConnexionManager _connexionManager;
    DonneesPerso _donneesPerso;
    public DonneesPerso donneesPerso {get => _donneesPerso; set => _donneesPerso = value;}
    List<Color> _couleursJoueur = new List<Color>();
    int _couleurActuelle = 0;
    PlayerInput _playerInput;
    InputAction _tournerCube;
    InputAction _changerCouleurDroite;
    InputAction _changerCouleurGauche;
    InputAction _pret;
    Vector2 _rotCube;
    bool _estEntrainEcrire = false;
    public List<Color> CouleursJoueur { get => _couleursJoueur; }
    public Color[] Couleurs { get => _couleurs; }
    public ConnexionManager ConnexionManager { get => _connexionManager; set => _connexionManager = value; }

    // Start is called before the first frame update
    void Awake()
    {
        _donneesPerso = ScriptableObject.CreateInstance<DonneesPerso>();
        
        _playerInput = GetComponent<PlayerInput>();
        _tournerCube = _playerInput.actions["TournerCube"];
        _changerCouleurDroite = _playerInput.actions["ChangerCouleurDroite"];
        _changerCouleurGauche = _playerInput.actions["ChangerCouleurGauche"];
        _pret = _playerInput.actions["Pret"];

        _nomJoueur.text = "Joueur " + (_playerInput.playerIndex + 1);

        foreach (Image image in _imagesChangerCouleurs)
        {
            image.gameObject.SetActive(true);
        }
        _imagePret.gameObject.SetActive(true);

        foreach (Color couleur in _couleurs)
        {
            _couleursJoueur.Add(couleur);
        }

        _changerCouleurGauche.performed += _ => ChangerCouleur(-1);
        _changerCouleurGauche.canceled += _ => _imagesChangerCouleurs[0].color = Color.white;
        _changerCouleurDroite.performed += _ => ChangerCouleur(1);
        _changerCouleurDroite.canceled += _ => _imagesChangerCouleurs[1].color = Color.white;
        _pret.performed += _ => ChangementPret();
        _pret.canceled += _ => _imagePret.color = Color.white;

        // Associe les actions d'entrée
        _tournerCube.performed += ctx => _rotCube = ctx.ReadValue<Vector2>();
        _tournerCube.canceled += _ => _rotCube = Vector2.zero;

        GetComponent<Renderer>().material.color = _couleursJoueur[_couleurActuelle];
        _donneesPerso.Couleur = _couleursJoueur[_couleurActuelle];

        _connexionManager.InitialiserDonnees(_donneesPerso, _playerInput.playerIndex);
    }

    void InitialiserCubes()
    {
        Color couleur = new Color(0, 0, 0, 1);
        // Type de cubes / Force des liens / Couleur / Nombre de cubes / Masse / Est kinematic
        _donneesPerso.Cubes.Add(new CubesType(CubesType.BlockType.Normal, 10, _donneesPerso.Couleur + couleur, 100));
        _donneesPerso.Cubes.Add(new CubesType(CubesType.BlockType.Sticky, 0, _donneesPerso.Couleur * .7f + couleur, 8, 2));
        _donneesPerso.Cubes.Add(new CubesType(CubesType.BlockType.Strong, 40, _donneesPerso.Couleur * .4f + couleur, 15));
        _donneesPerso.Cubes.Add(new CubesType(CubesType.BlockType.Indestructible, 30, _donneesPerso.Couleur * .1f + couleur, 4, 1, true));
        _donneesPerso.Cubes.Add(new CubesType(CubesType.BlockType.Core, 0, Color.white, 1, 1, true));
    }

    // Update is called une fois par frame
    void Update()
    {
        // Applique la rotation à l'objet
        if (_rotCube != Vector2.zero && !_estEntrainEcrire)
        {
            float rotationX = _rotCube.y * _vitesseRotation * Time.deltaTime; // Haut/Bas
            float rotationY = _rotCube.x * _vitesseRotation * Time.deltaTime; // Gauche/Droite

            // Effectue la rotation
            transform.Rotate(Vector3.right, -rotationX, Space.Self); // Rotation verticale (locale)
            transform.Rotate(Vector3.up, rotationY, Space.World);   // Rotation horizontale (globale)
        }
    }

    public void ChangerCouleur(int direction)
    {
        SoundManager.instance.PlaySFX(EnumSFX.bouton, null); // Jouer le son du bouton
        _imagesChangerCouleurs[direction == -1 ? 0 : 1].color = Color.grey;
        _couleurActuelle += direction;
        if (_couleurActuelle >= _couleursJoueur.Count)
        {
            _couleurActuelle = 0;
        }
        else if (_couleurActuelle < 0)
        {
            _couleurActuelle = _couleursJoueur.Count - 1;
        }
        GetComponent<Renderer>().material.color = _couleursJoueur[_couleurActuelle];
        _donneesPerso.Couleur = _couleursJoueur[_couleurActuelle];
    }

    public void ChangementPret()
    {
        SoundManager.instance.PlaySFX(EnumSFX.bouton, null); // Jouer le son du bouton
        _donneesPerso.EstPret = !_donneesPerso.EstPret;

        if (_donneesPerso.EstPret)
        {
            _changerCouleurDroite.Disable();
            _changerCouleurGauche.Disable();
        }
        else
        {
            _changerCouleurDroite.Enable();
            _changerCouleurGauche.Enable();
        }

        _imagePret.color = Color.gray;

        foreach (var image in _imagesChangerCouleurs)
        {
            image.color = _donneesPerso.EstPret ? image.color * new Color(1, 1, 1, .5f) : Color.white;
        }

        if (_donneesPerso.EstPret)
        {
            InitialiserCubes();
        }

        _connexionManager.JoueurPret(_donneesPerso);
    }

    public void EcrireNom()
    {
        _estEntrainEcrire = !_estEntrainEcrire;
    }
}
