using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class CubeFantome : MonoBehaviour
{
    [SerializeField] GameObject Origin;
    List<GameObject> _collisions = new List<GameObject>();

    public GameObject GetOrigin()
    {
        return Origin;
    }

    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Alpha0))
        {
            DebugCollisions();
        }
    }

    void DebugCollisions()
    {
        string collisions = "";

        for (int i = 0; i < _collisions.Count; i++)
        {
           collisions += _collisions[i] + ", ";
        }

        Debug.Log(collisions);
    }

    public bool GetCollisions()
    {
        if (_collisions.Count > 0) return true;
        else return false;
    }
    
    void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.tag != "Block" || other.gameObject.tag != "Grid" || other.gameObject.tag != "Player")
        {
            _collisions.Add(other.gameObject);
        }
    }
    
    void OnTriggerExit(Collider other)
    {
        if(other.gameObject.tag != "Block" || other.gameObject.tag != "Grid" || other.gameObject.tag != "Player")
        {
            _collisions.Add(other.gameObject);   
        }
    }
}
