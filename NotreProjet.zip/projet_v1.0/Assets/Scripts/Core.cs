using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Animations;
using UnityEngine.InputSystem;

public class Core : MonoBehaviour
{
    [SerializeField] GameObject Origin;
    [SerializeField] Camera _cam;
    public Camera coreCam => _cam;
    [SerializeField] GameObject _camAnchor;
    [SerializeField] GameObject _projectile;
    [SerializeField] GameObject _marker;
    [SerializeField] GameObject _cube;
    [SerializeField] ParticleSystem _death;

    [SerializeField] bool _showTrajectory = false;
    [SerializeField, Range(0, 2)] float _speed = 0.1f;
    // [SerializeField, Range(0, 360)] int _verticalLimitLow = 0;
    // [SerializeField, Range(0, 360)] int _verticalLimitHigh = 0;
    // [SerializeField, Range(0, 360)] int _horizontalLimitLow = 360;
    // [SerializeField, Range(0, 360)] int _horizontalLimitHigh = 360;

    [SerializeField, Range(0, 30)] float _projectileVelocity = 10;
    [SerializeField, Range(0, 60)] float _incomingProjectileVelocityForDeath = 10;
    int _projectileAngle = 30;

    List<GameObject> trajectoryMarkers = new List<GameObject>();
    float _markersAmount = 5;
    float _rotationX;
    float _rotationY;

    public bool hasShot = true;

    float GRAVITY = 9.79f;

    void Start()
    {
        InitTrajectoryMarkers();
    }

    void Update()
    {
        float xAxis = _camAnchor.transform.rotation.eulerAngles.x + (_rotationX * _speed * 100 * Time.deltaTime);
        float yAxis = _camAnchor.transform.rotation.eulerAngles.y + (_rotationY * _speed * 100 * Time.deltaTime);


        // xAxis = Mathf.Clamp(xAxis, _verticalLimitLow, -_verticalLimitHigh);
        // yAxis = Mathf.Clamp(yAxis, -_horizontalLimitLow, _horizontalLimitHigh);

        _camAnchor.transform.rotation = Quaternion.Euler(xAxis, yAxis, 0);
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Projectile")
        {
            if (collision.gameObject.GetComponent<Rigidbody>().velocity.magnitude > _incomingProjectileVelocityForDeath)
            {
                transform.parent.transform.parent.GetComponent<GameManager>().SetCoreDestroyed(transform.parent.GetComponentInChildren<BuildingZone>().data.Index + 1);

                _cube.SetActive(false);
                GameObject part = Instantiate(_death.gameObject, transform.position, Quaternion.identity);
                part.GetComponent<ParticleSystem>().Play();

                SoundManager.instance.PlaySFX(EnumSFX.Collision, null); // Jouer le son du bouton
            }
        }
    }

    void InitTrajectoryMarkers()
    {
        for (int i = 0; i < _markersAmount; i++)
        {
            trajectoryMarkers.Add(Instantiate(_marker, _camAnchor.transform.position, Quaternion.identity, transform));
        }
        foreach (var marker in trajectoryMarkers) marker.SetActive(false);
    }

    public GameObject GetOrigin()
    {
        return Origin;
    }

    void UpdateTrajectory()
    {
        // float camAngle = _camAnchor.transform.rotation.x * Mathf.Rad2Deg + 180;
        float camAngle = _camAnchor.transform.rotation.x;



        float hVelocity = Mathf.Abs(Mathf.Cos(camAngle + _projectileAngle) * _projectileVelocity);
        float vVelocity = Mathf.Abs(Mathf.Sin(camAngle + _projectileAngle) * _projectileVelocity);

        // Debug.Log($"({hVelocity}, {vVelocity})");

        for (int i = 0; i < 5; i++)
        {
            float t = i / 5f;

            float horizontal = hVelocity * t - .5f * GRAVITY * Mathf.Pow(t, 2);
            float vertical = vVelocity * t;

            // points.Add(new Vector3(0, vertical, horizontal));

            Vector3 pos = (_camAnchor.transform.forward + _camAnchor.transform.forward * .5f) * vertical + (_camAnchor.transform.up + _camAnchor.transform.up * .5f) * horizontal + _camAnchor.transform.position;
            pos = pos + _camAnchor.transform.forward + _camAnchor.transform.up;

            trajectoryMarkers[i].transform.position = pos;
        }
    }

    void OnLook(InputValue value)
    {
        if (!hasShot)
        {
            Vector2 inputVector = value.Get<Vector2>();
            _rotationX = -inputVector.y;
            _rotationY = inputVector.x;
            if (_showTrajectory)
            {
                foreach (var marker in trajectoryMarkers)
                {
                    marker.SetActive(true);
                }
                UpdateTrajectory();
            }
            else
            {
                foreach (var marker in trajectoryMarkers) marker.SetActive(false);
            }
        }
    }

    void OnFire(InputValue value)
    {
        if (value.Get<float>() == 1 && !hasShot)
        {
            SoundManager.instance.PlaySFX(EnumSFX.tir, null); // Jouer le son du bouton
            hasShot = true;
            _showTrajectory = false;
            StartCoroutine(DisableMarkers());
            transform.parent.transform.parent.GetComponent<GameManager>().SetPlayerHasShot(transform.parent.GetComponentInChildren<BuildingZone>().data.Index + 1, true);

            GameObject projectile = Instantiate(_projectile, transform.position + (_camAnchor.transform.forward + _camAnchor.transform.up) * 1.5f, Quaternion.identity);
            Rigidbody projectileRb = projectile.GetComponent<Rigidbody>();

            // projectileRb.AddForce(_camAnchor.transform.forward * 10, ForceMode.Impulse);
            float forwardFactor = Mathf.Abs(Mathf.Sin(_camAnchor.transform.rotation.x + _projectileAngle) * _projectileVelocity);
            float upFactor = Mathf.Abs(Mathf.Cos(_camAnchor.transform.rotation.x + _projectileAngle) * _projectileVelocity);
            projectileRb.velocity = _camAnchor.transform.forward * forwardFactor + _camAnchor.transform.up * upFactor;
        }
    }

    IEnumerator DisableMarkers()
    {
        yield return new WaitForSeconds(3);
        foreach (var marker in trajectoryMarkers) marker.SetActive(false);
    }

    public void ResetHasShot()
    {
        hasShot = false;
        _showTrajectory = true;
        transform.parent.transform.parent.GetComponent<GameManager>().SetPlayerHasShot(transform.parent.GetComponentInChildren<BuildingZone>().data.Index + 1, false);
    }
}
