public enum EnumSFX
{
    bouton,
    tir,
    tournerBase,
    Collision,
    PlacerCube,
    RetirerCube
}