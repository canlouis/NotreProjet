using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

[CreateAssetMenu(fileName = "NouveauJoueur", menuName = "Données/Joueur")]
public class DonneesPerso : ScriptableObject
{
    [Header("Informations de base")]
    private bool _estPret = false;
    private InputDevice _input;
    private int _index = 0;
    private Color _couleur = Color.white;
    private int _score = 0;
    List<CubesType> _cubes = new List<CubesType>();

    public InputDevice input { get => _input; set => _input = value; }
    public int Index { get => _index; set => _index = value; }
    public Color Couleur { get => _couleur; set => _couleur = value; }
    public int Score { get => _score; set => _score = value; }
    public bool EstPret { get => _estPret; set => _estPret = value; }
    public List<CubesType> Cubes { get => _cubes; set => _cubes = value; }
}
