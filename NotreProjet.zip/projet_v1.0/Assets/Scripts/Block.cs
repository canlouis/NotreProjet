using System.Collections.Generic;
using UnityEngine;

public class Block : MonoBehaviour
{
    [SerializeField] GameObject Origin;
    CubesType.BlockType _type;
    float _breakForce;
    Color _cubeCouleur;
    float _mass;
    bool _isKinematic;

    [SerializeField] Material _matInvisible;
    Material _baseMat;

    List<GameObject> _jointedObjects = new List<GameObject>();
    List<ConfigurableJoint> _joints = new List<ConfigurableJoint>();

    Rigidbody _rb;
    public CubesType.BlockType type => _type;

    void Start()
    {
        _rb = GetComponent<Rigidbody>();
        SetProperties();
        if (GetComponentInParent<BuildingZone>().enableBuildMode) EnableBuildMode();
        else DisableBuildMode();
    }

    void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.tag == "Block" && _jointedObjects.Contains(other.gameObject) == false)
        {
            SetJoint(other.gameObject);
        }
    }

    public GameObject GetOrigin()
    {
        return Origin;
    }

    public void EnableBuildMode()
    {
        _rb.isKinematic = true;
    }

    public void DisableBuildMode()
    {
        SetProperties();
    }
    
    public void EnableFireMode()
    {
        transform.GetChild(0).GetComponent<MeshRenderer>().material = _matInvisible;
    }

    public void DisableFireMode()
    {
        transform.GetChild(0).GetComponent<MeshRenderer>().material = _baseMat;
    }

    public void GetCubeProperties(CubesType cubesType)
    {
        _type = cubesType.Type;
        _breakForce = cubesType.ForceLiens;
        _cubeCouleur = cubesType.CubeCouleur;
        _mass = cubesType.Masse;
        _isKinematic = cubesType.Estkinematic;
    }

    void SetProperties()
    {
        _rb.mass = _mass;
        Material material = new Material(transform.GetChild(0).GetComponent<MeshRenderer>().material);
        _baseMat = material;
        material.SetColor("_BaseColor", _cubeCouleur);
        material.SetColor("_EmissionColor", _cubeCouleur);
        transform.GetChild(0).GetComponent<MeshRenderer>().material = material;
        _rb.isKinematic = _isKinematic;

        // if (transform.position.y == 0) _rb.isKinematic = true;
        // else _rb.isKinematic = false;
    }

    void SetJoint(GameObject contact)
    {

        ConfigurableJoint jt = gameObject.AddComponent<ConfigurableJoint>();
        jt.connectedBody = contact.gameObject.GetComponent<Rigidbody>();
        jt.enableCollision = true;
        jt.anchor = Origin.transform.localPosition + Vector3.one * .5f;

        switch (_type)
        {

            case CubesType.BlockType.Normal:
                jt.xMotion = ConfigurableJointMotion.Limited;
                jt.yMotion = ConfigurableJointMotion.Limited;
                jt.zMotion = ConfigurableJointMotion.Limited;
                break;

            case CubesType.BlockType.Strong:
                jt.xMotion = ConfigurableJointMotion.Limited;
                jt.yMotion = ConfigurableJointMotion.Limited;
                jt.zMotion = ConfigurableJointMotion.Limited;
                break;

            case CubesType.BlockType.Sticky:
                if (contact.GetComponent<Block>() != null && _type == contact.GetComponent<Block>().type)
                {
                    jt.xMotion = ConfigurableJointMotion.Locked;
                    jt.yMotion = ConfigurableJointMotion.Locked;
                    jt.zMotion = ConfigurableJointMotion.Locked;
                    jt.angularXMotion = ConfigurableJointMotion.Locked;
                    jt.angularYMotion = ConfigurableJointMotion.Locked;
                    jt.angularZMotion = ConfigurableJointMotion.Locked;
                    jt.breakForce = float.PositiveInfinity;
                }
                else
                {
                    jt.xMotion = ConfigurableJointMotion.Limited;
                    jt.yMotion = ConfigurableJointMotion.Limited;
                    jt.zMotion = ConfigurableJointMotion.Limited;
                }
                break;

            case CubesType.BlockType.Indestructible:
                jt.xMotion = ConfigurableJointMotion.Limited;
                jt.yMotion = ConfigurableJointMotion.Limited;
                jt.zMotion = ConfigurableJointMotion.Limited;
                break;
        }

        jt.breakForce = _breakForce;
        _joints.Add(jt);
        _jointedObjects.Add(contact);
    }
}