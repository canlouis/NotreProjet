using System;
using UnityEngine;

[System.Serializable]
public class CubesType
{
    public enum BlockType { Normal, Strong, Sticky, Indestructible, Core };
    BlockType _type;        // Type de pouvoir
    int _forceLiens;         // Coût en âmes pour utiliser le pouvoir
    Color _cubeCouleur; // Temps ou charge nécessaire pour activer
    bool _estkinematic;
    float _masse;
    int  _nbCubes;        // Icône du pouvoir
    int _nbCubesRestant;        // Icône du pouvoir

    public BlockType Type { get => _type; }
    public int ForceLiens { get => _forceLiens; }
    public Color CubeCouleur { get => _cubeCouleur; }
    public bool Estkinematic { get => _estkinematic; }
    public float Masse { get => _masse; }
    public int NbCubes { get => _nbCubes; }
    public int NbCubesRestant { get => _nbCubesRestant; set => _nbCubesRestant = value; }

    public CubesType(BlockType type, int forceLiens, Color cubeCouleur, int nbCubes, float masse = 1, bool estkinematic = false)
    {
        _type = type;
        _forceLiens = forceLiens;
        _cubeCouleur = cubeCouleur;
        _nbCubes = nbCubes;
        _nbCubesRestant = nbCubes;
        _estkinematic = estkinematic;
        _masse = masse;
    }
}