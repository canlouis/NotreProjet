using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Samuel
/// Handles music and sound effects
/// Is a Singleton
/// </summary>
public class SoundManager : MonoBehaviour
{
    private static SoundManager _instance;                                  // private instance of SoundManager
    public static SoundManager instance { get { return _instance; } }       // public instance of SoundManager
    public bool isReady = false;

    private Coroutine _musicFade;                                           // Coroutine to fade music

    [SerializeField, Range(0, 5f)] float _crossFadeDuration = 1f;           // Music transition duration in seconds with a range of 0 to 5
    [SerializeField, Range(0, 1f)] float _musicVolume = 0.2f;               // Music volume with a range of 0 to 1

    public AudioSource _FallbackAudioSource;                                // AudioSource to play sound effects
    List<AudioSource> musicsAudioSources = new List<AudioSource>();         // List of AudioSources for musics

    [SerializeField] GameObject _SFXSlot;                                   // GameObject for the SFX slot
    [SerializeField] GameObject[] musics;                                   // Array of GameObjects for musics

    // AudioClips arrays
    [SerializeField] AudioClip[] sfxPlacerCube;
    [SerializeField] AudioClip[] sfxTir;
    [SerializeField] AudioClip[] sfxRetirerCube;
    [SerializeField] AudioClip[] sfxTournerBase;
    [SerializeField] AudioClip[] sfxBouton;
    [SerializeField] AudioClip[] sfxCollision;


    void Awake()
    {
        if (_instance == null) _instance = this;
        else Destroy(gameObject);
    }

    void Start()
    {
        DontDestroyOnLoad(gameObject);
        GetSlotAudioSources();
        GetMusicsAudioSources();
        isReady = true;
    }


    /* ----------------------------- Audio sources getters ----------------------------- */
    /// <summary>
    /// Samuel
    /// Gets the AudioSource object of the sound effects slot
    /// </summary>
    void GetSlotAudioSources()
    {
        _FallbackAudioSource = _SFXSlot.GetComponent<AudioSource>();
    }

    /// <summary>
    /// Samuel
    /// Gets the AudioSource object of the audio tracks
    /// </summary>
    void GetMusicsAudioSources()
    {
        for (int i = 0; i < musics.Length; i++)
        {
            musicsAudioSources.Add(musics[i].GetComponent<AudioSource>());

            // Sets the volume of the audio tracks to 0 (except the base one)
            if (i != 0)
            {
                musicsAudioSources[i].volume = 0;
            }
        }
    }


    /* ----------------------------- Play a sound in a free slot ----------------------------- */

    /// <summary>
    /// Samuel
    /// Plays a sound in the specified AudioSource. If no AudioSource is provided, the sound is played in the default AudioSource
    /// </summary>
    void PlaySound(AudioClip clip, AudioSource source)
    {
        if (source == null) source = _FallbackAudioSource;
        source.PlayOneShot(clip);
        source.pitch = Random.Range(0.98f, 1.02f);
    }


    /* ----------------------------- Méthodes pour les demandes externes ----------------------------- */
    /// <summary>
    /// Samuel
    /// Handles the request to play a sound based on its ENUM. Picks a sound from the appropriate array (Adds variety)
    /// </summary>
    public void PlaySFX(EnumSFX name, AudioSource source)
    {
        switch (name)
        {
            case EnumSFX.bouton:
                PlaySound(sfxBouton[Random.Range(0, sfxBouton.Length)], source);
                break;

            case EnumSFX.tir:
                PlaySound(sfxTir[Random.Range(0, sfxTir.Length)], source);
                break;

            case EnumSFX.Collision:
                PlaySound(sfxCollision[Random.Range(0, sfxCollision.Length)], source);
                break;

            case EnumSFX.PlacerCube:
                PlaySound(sfxPlacerCube[Random.Range(0, sfxPlacerCube.Length)], source);
                break;

            case EnumSFX.RetirerCube:
                PlaySound(sfxRetirerCube[Random.Range(0, sfxRetirerCube.Length)], source);
                break;

            case EnumSFX.tournerBase:
                PlaySound(sfxTournerBase[Random.Range(0, sfxTournerBase.Length)], source);
                break;

            default:
                Debug.LogWarning("This sound doesn't exist.");
                break;
        }
    }
}