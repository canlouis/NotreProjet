using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class BuildingZone : MonoBehaviour
{
    [SerializeField] int _zoneSize = 10;
    public int zoneSize => _zoneSize;
    [SerializeField] GameObject Origin;
    [SerializeField] GameObject Grid;
    [SerializeField] GameObject AnchorPoint;
    [SerializeField] GameObject Block;

    PlayerInput _input;
    public PlayerInput input => _input;

    public DonneesPerso data;

    GameObject[,] anchors;
    List<Block> blocks = new List<Block>();
    public List<Block> Blocks { get => blocks; set => blocks = value; }

    bool _enableBuildMode = false;
    public bool enableBuildMode => _enableBuildMode;


    void Start()
    {
        anchors = new GameObject[_zoneSize, _zoneSize];
        _input = GetComponent<PlayerInput>();
        SetupGrid();
        EnableBuildMode();
    }


    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            if (_enableBuildMode) DisableBuildMode();
            else EnableBuildMode();
        }
    }

    public GameObject GetOrigin()
    {
        return Origin;
    }

    public void EnableBuildMode()
    {
        foreach (Block block in blocks)
        {
            block.EnableBuildMode();
        }
        _enableBuildMode = true;
    }

    public void DisableBuildMode()
    {
        foreach (Block block in blocks)
        {
            block.DisableBuildMode();
        }
        _enableBuildMode = false;
    }

    public void EnableFireMode()
    {
        foreach (Block cube in blocks)
        {
            cube.EnableFireMode();
        }
    }
    public void DisableFireMode()
    {
        foreach (Block cube in blocks)
        {
            cube.DisableFireMode();
        }
    }

    void SetupGrid()
    {
        for (int x = 0; x < _zoneSize; x++)
        {
            for (int z = 0; z < _zoneSize; z++)
            {
                Vector3 pos = new Vector3(Origin.transform.position.x + x, 0, Origin.transform.position.z + z);
                GameObject localAnchor = Instantiate(AnchorPoint, pos, Quaternion.identity, Origin.transform);
                anchors[x, z] = localAnchor;
            }
        }
    }

    public void PlaceCube(Transform anchor, GameObject cube, int playerIndex, int selectedBlock)
    {
        GameObject block = Instantiate(cube, anchor.position, Quaternion.identity, Grid.transform);

        if (cube.GetComponent<Block>() != null)
        {
            blocks.Add(block.GetComponent<Block>());
            block.GetComponent<Block>().GetCubeProperties(PlayerManager.Instance.DonneesPersos[playerIndex].Cubes[selectedBlock]);
        }
        else if (block.GetComponent<Core>() != null)
        {
            block.transform.parent = transform.parent;
        }
    }

    void OnSpinRight()
    {
        SoundManager.instance.PlaySFX(EnumSFX.tournerBase, null); // Jouer le son du bouton
        if (data.Index == 0)
        {
            transform.parent.transform.RotateAround(new Vector3(_zoneSize, 0, _zoneSize) * .5f, Vector3.up, 90);
        }
        else
        {
            transform.parent.transform.RotateAround(new Vector3(25, 0, 0) + new Vector3(_zoneSize, 0, _zoneSize) * .5f, Vector3.up, 90);
        }
    }

    void OnSpinLeft()
    {
        SoundManager.instance.PlaySFX(EnumSFX.tournerBase, null); // Jouer le son du bouton
        if (data.Index == 0)
        {
            transform.parent.transform.RotateAround(new Vector3(_zoneSize, 0, _zoneSize) * .5f, Vector3.up, -90);
        }
        else
        {
            transform.parent.transform.RotateAround(new Vector3(25, 0, 0) + new Vector3(_zoneSize, 0, _zoneSize) * .5f, Vector3.up, -90);
        }
    }

    void OnConfirm()
    {
        if (data.Index == 0)
        {
            transform.parent.parent.GetComponent<GameManager>().SetPlayerReady(0, true);
        }
        else
        {
            transform.parent.parent.GetComponent<GameManager>().SetPlayerReady(1, true);
        }

        foreach (Block cube in blocks)
        {
            if (cube == null)
            {
                StartCoroutine(Remove(cube));
            }
        }
    }

    IEnumerator Remove(Block cube)
    {
        yield return new WaitForSeconds(.3f);
        blocks.Remove(cube);
    }
}
