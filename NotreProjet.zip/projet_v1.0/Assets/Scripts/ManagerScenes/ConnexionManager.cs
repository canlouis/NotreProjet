using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.InputSystem;
using UnityEngine.Events;

public class ConnexionManager : MonoBehaviour
{
    [SerializeField] GestionnaireScenes _gestionnaireScenes;
    [SerializeField] Transform[] _posJoueursConnexion;
    [SerializeField] TextMeshProUGUI _texteDecompte;
    List<DonneesPerso> _donneesPersos = new List<DonneesPerso>();
    PlayerInputManager _playerInputManager;
    int _nbJoueursPrets = 0;

    void Start()
    {
        _texteDecompte.gameObject.SetActive(false);
        _playerInputManager = PlayerManager.Instance.GetComponent<PlayerInputManager>();
        PlayerManager.Instance.AjouterJoueur += joueur => AjouterJoueur(joueur);
        }

    public void JoueurPret(DonneesPerso donneesPerso)
    {
        int indexAutreJoueur = donneesPerso.Index == 0 ? 1 : 0;

        if (donneesPerso.EstPret)
        {
            _nbJoueursPrets++;
            _donneesPersos[donneesPerso.Index] = donneesPerso;

            if (PlayerManager.Instance.DonneesPersos.Count == _playerInputManager.maxPlayerCount && _donneesPersos[indexAutreJoueur] != null && _donneesPersos[1].Couleur == _donneesPersos[0].Couleur)
            {
                PlayerManager.Instance.Joueurs[_donneesPersos[indexAutreJoueur].Index].CouleursJoueur.Remove(donneesPerso.Couleur);
                PlayerManager.Instance.Joueurs[_donneesPersos[indexAutreJoueur].Index].ChangerCouleur(0);
            }
        }
        else
        {
            if (PlayerManager.Instance.DonneesPersos.Count == _playerInputManager.maxPlayerCount)
            {
                PlayerManager.Instance.Joueurs[_donneesPersos[indexAutreJoueur].Index].CouleursJoueur.Clear();
                foreach (Color couleur in PlayerManager.Instance.Joueurs[_donneesPersos[indexAutreJoueur].Index].Couleurs)
                {
                    PlayerManager.Instance.Joueurs[_donneesPersos[indexAutreJoueur].Index].CouleursJoueur.Add(couleur);
                }
            }
            _nbJoueursPrets--;
        }

        if (_nbJoueursPrets == _playerInputManager.maxPlayerCount)
        {
            _texteDecompte.gameObject.SetActive(true);
            StartCoroutine(Decompte());
        }
        else
        {
            StopAllCoroutines();
            _texteDecompte.gameObject.SetActive(false);
        }
    }

    public void AjouterJoueur(PlayerInput joueur)
    {
        joueur.GetComponent<JoueurConnexion>().ConnexionManager = this;
        joueur.transform.parent.transform.parent = _posJoueursConnexion[joueur.playerIndex];
        joueur.transform.parent.localPosition = Vector3.zero;
    }

    public void InitialiserDonnees(DonneesPerso donneesPerso, int index)
        {
        _donneesPersos.Add(donneesPerso);

        if (index == 1 && _donneesPersos[0].EstPret && _donneesPersos[1].Couleur == _donneesPersos[0].Couleur)
        {
            PlayerManager.Instance.Joueurs[index].CouleursJoueur.Remove(_donneesPersos[index].Couleur);
            PlayerManager.Instance.Joueurs[index].ChangerCouleur(0);
        }
    }

    IEnumerator Decompte()
    {
        _texteDecompte.text = "3";
        yield return new WaitForSeconds(1);
        _texteDecompte.text = "2";
        yield return new WaitForSeconds(1);
        _texteDecompte.text = "1";
        yield return new WaitForSeconds(1);
        _texteDecompte.text = "GO!";
        yield return new WaitForSeconds(1);

        foreach (DonneesPerso donneesPerso in _donneesPersos)
        {
            donneesPerso.EstPret = false;
            donneesPerso.Couleur = PlayerManager.Instance.Joueurs[donneesPerso.Index].GetComponent<Renderer>().material.color;
        }
        _gestionnaireScenes.ChargerScene("Jeu");
    }
}