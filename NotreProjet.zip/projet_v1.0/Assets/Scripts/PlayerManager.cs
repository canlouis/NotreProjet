using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

public class PlayerManager : MonoBehaviour
{
    public static PlayerManager Instance { get; private set; }
    PlayerInputManager _playerInputManager;
    List<JoueurConnexion> _joueurs = new List<JoueurConnexion>();
    List<DonneesPerso> _donneesPersos = new List<DonneesPerso>();
    public List<JoueurConnexion> Joueurs { get => _joueurs; }
    public List<DonneesPerso> DonneesPersos { get => _donneesPersos; set => _donneesPersos = value; }
    public delegate void AjoutJoueur(PlayerInput joueur);
    AjoutJoueur _ajoutJoueur;
    public AjoutJoueur AjouterJoueur { get => _ajoutJoueur; set => _ajoutJoueur = value; }

    int _playersInLobby = 0;

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }

        _playerInputManager = GetComponent<PlayerInputManager>();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1)) Time.timeScale = 1f;
        if (Input.GetKeyDown(KeyCode.Alpha2)) Time.timeScale = 2f;
        if (Input.GetKeyDown(KeyCode.Alpha3)) Time.timeScale = 3f;
    }

    public void OnPlayerJoined(PlayerInput joueur)
    {
        if (SceneManager.GetActiveScene().name != "Jeu")
        {
            _joueurs.Add(joueur.GetComponent<JoueurConnexion>());
            if (AjouterJoueur != null)
            {
                AjouterJoueur(joueur);
            }

            StartCoroutine(AddPlayer(joueur));
        }
    }

    IEnumerator AddPlayer(PlayerInput joueur)
    {
        yield return new WaitUntil(() => joueur.GetComponent<JoueurConnexion>() != null);
        yield return new WaitUntil(() => joueur.GetComponent<JoueurConnexion>().donneesPerso != null);


        _playersInLobby++;

        _donneesPersos.Add(_joueurs[_playersInLobby - 1].donneesPerso);
        _donneesPersos[_playersInLobby - 1].Index = _playersInLobby - 1;

        if (_joueurs.Count == _playerInputManager.maxPlayerCount)
        {
            _playerInputManager.DisableJoining();
        }
    }
}