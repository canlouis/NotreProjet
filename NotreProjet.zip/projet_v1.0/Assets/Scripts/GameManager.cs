using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    [SerializeField] float _distanceEntreZones = 10;
    [SerializeField] GameObject _playerPrefab;
    List<DonneesPerso> _playerData = new List<DonneesPerso>();
    List<GameObject> _players = new List<GameObject>();
    PlayerInputManager _inputManager;
    bool _inMatch = false;

    [Header("Player 1")]
    GameObject _zoneConstructionJoueur1;
    GameObject _joueur1;
    GameObject _coreJoueur1;
    GameObject _cameraConstructionJoueur1;
    GameObject _cameraCoreJoueur1;
    GameObject _cameraTopJoueur1;

    [Header("Player 2")]
    GameObject _zoneConstructionJoueur2;
    GameObject _joueur2;
    GameObject _coreJoueur2;
    GameObject _cameraConstructionJoueur2;
    GameObject _cameraCoreJoueur2;
    GameObject _cameraTopJoueur2;
    bool _player1HasShot = false;
    bool _player2HasShot = false;

    [Header("Cameras")]
    [SerializeField] GameObject _cineCam;
    [SerializeField] GameObject _cineCamTarget;
    [SerializeField] int _cineCamAngleBeforeAttack;
    [SerializeField, Range(0f, 1f)] float _cineCamLerpSpeed;
    [SerializeField, Range(0, 100)] float _cineCamRotationSpeed;

    [Header("Construction")]
    [SerializeField] int _constructionTempsMax = 60;
    int _zoneSize = 0;
    int _timerConstruction = 0;
    Coroutine _coroutineTimerConstruction;

    [Header("UI")]
    [SerializeField, Range(0, 5)] float _blackscreenDelay;
    [SerializeField] Image _blackscreen;
    [SerializeField] Image _split;
    [SerializeField] Image _player1Image;
    [SerializeField] Image _player2Image;
    [SerializeField] Image _player1BaseImage;
    [SerializeField] Image _player2BaseImage;
    [SerializeField] Image _turnPlayer1Image;
    [SerializeField] Image _turnPlayer2Image;
    [SerializeField] GameObject _instructions;


    bool _player1CoreDestroyed = false;
    bool _player2CoreDestroyed = false;



    // Initialisation
    void Start()
    {
        _inputManager = PlayerManager.Instance.GetComponent<PlayerInputManager>();
        _playerData = PlayerManager.Instance.DonneesPersos;

        _inputManager.DisableJoining();

        InitPlayers();

        StartCoroutine(ConstructionSequence());
    }

    void InitPlayers()
    {
        _inputManager.splitScreen = true;

        GameObject first = Instantiate(_playerPrefab, new Vector3(0 * _distanceEntreZones, 0, 0), Quaternion.identity, transform);
        GameObject second = Instantiate(_playerPrefab, new Vector3(1 * _distanceEntreZones, 0, 0), Quaternion.identity, transform);


        foreach (DonneesPerso player in _playerData)
        {
            if (player.Index == 0)
            {
                _joueur1 = first;
                // _joueur1.transform.position = new Vector3(0 * _distanceEntreZones, 0, 0);
                _cameraConstructionJoueur1 = _joueur1.GetComponentInChildren<ConstructionCam>().gameObject;
                _zoneConstructionJoueur1 = _cameraConstructionJoueur1.GetComponent<ConstructionCam>().buildingZone.gameObject;
                _zoneConstructionJoueur1.GetComponent<PlayerInput>().enabled = false;
                _zoneConstructionJoueur1.GetComponent<BuildingZone>().data = player;
                _zoneConstructionJoueur1.GetComponentInChildren<MeshRenderer>().material.SetColor("_Color", player.Couleur);

                // _cameraConstructionJoueur1.transform.position = _zoneConstructionJoueur1.transform.position + Vector3.one * 2;
                // _inputManager.JoinPlayer(-1, -1, "Gamepad", player.input);
                // _zoneConstructionJoueur1.GetComponent<BuildingZone>().input.camera = _cineCam.GetComponent<Camera>();
                // Debug.Log("Player " + _playerData[0].Index + " in game at " + (_zoneConstructionJoueur1.transform.position + Vector3.one * 2));
            }
            else
            {
                _joueur2 = second;
                // _joueur2.transform.position = new Vector3(1 * _distanceEntreZones, 0, 0);
                _cameraConstructionJoueur2 = _joueur2.GetComponentInChildren<ConstructionCam>().gameObject;
                _zoneConstructionJoueur2 = _cameraConstructionJoueur2.GetComponent<ConstructionCam>().buildingZone.gameObject;
                _zoneConstructionJoueur2.GetComponent<PlayerInput>().enabled = false;
                _zoneConstructionJoueur2.GetComponent<BuildingZone>().data = player;
                _zoneConstructionJoueur2.GetComponentInChildren<MeshRenderer>().material.SetColor("_Color", player.Couleur);

                // _cameraConstructionJoueur2.transform.position = _zoneConstructionJoueur2.transform.position + Vector3.one * 2;
                // _inputManager.JoinPlayer(0, 0, "Gamepad", player.input);
                // _zoneConstructionJoueur2.GetComponent<BuildingZone>().input.camera = _cineCam.GetComponent<Camera>();
                // Debug.Log("Player " + _playerData[1].Index + " in game at " + (_zoneConstructionJoueur2.transform.position + Vector3.one * 2));
            }
        }

        _cineCam.SetActive(false);
    }


    // Players Settings
    public void SetPlayerReady(int playerIndex, bool ready)
    {
        PlayerManager.Instance.DonneesPersos[playerIndex].EstPret = ready;
        }

    public void SetPlayerHasShot(int playerIndex, bool hasShot)
    {
        switch (playerIndex)
        {
            case 1:
                _player1HasShot = hasShot;
                break;
            case 2:
                _player2HasShot = hasShot;
                break;
        }
    }

    public void SetCoreDestroyed(int playerIndex)
    {
        switch (playerIndex)
        {
            case 1:
                _player1CoreDestroyed = true;
                break;
            case 2:
                _player2CoreDestroyed = true;
                break;
        }
    }


    // Match
    IEnumerator ConstructionSequence()
    {
        Debug.Log("Construction Sequence");
        _cineCam.SetActive(false);
        _player1Image.enabled = true;
        _player2Image.enabled = true;

        yield return new WaitUntil(() => _joueur1 != null && _joueur2 != null);
        _split.gameObject.SetActive(true);
        EnablePlayersConstruction(true);
        DisablePlayersSpin();
        _zoneConstructionJoueur1.GetComponent<BuildingZone>().EnableBuildMode();
        _zoneConstructionJoueur2.GetComponent<BuildingZone>().EnableBuildMode();

        _zoneSize = _zoneConstructionJoueur1.GetComponent<BuildingZone>().zoneSize;

        yield return new WaitUntil(() => PlayerManager.Instance.DonneesPersos[0].EstPret && PlayerManager.Instance.DonneesPersos[1].EstPret);

        SetPlayerReady(0, false);
        SetPlayerReady(1, false);

        // Fade out noir
        float opacity = 0;
        while (opacity < 1)
        {
            opacity += Time.deltaTime;
            _blackscreen.color = new Color(0, 0, 0, opacity);
            yield return null;
        }
        yield return new WaitForSeconds(_blackscreenDelay);

        _player1Image.enabled = false;
        _player2Image.enabled = false;

        StartCoroutine(CinematicSequence());
    }

    IEnumerator CinematicSequence()
    {
        _coreJoueur1 = _joueur1.GetComponentInChildren<Core>().gameObject;
        _cameraCoreJoueur1 = _coreJoueur1.GetComponent<Core>().coreCam.gameObject;
        _cameraCoreJoueur1.SetActive(false);
        _coreJoueur1.GetComponent<PlayerInput>().enabled = false;

        _coreJoueur2 = _joueur2.GetComponentInChildren<Core>().gameObject;
        _cameraCoreJoueur2 = _coreJoueur2.GetComponent<Core>().coreCam.gameObject;
        _cameraCoreJoueur2.SetActive(false);
        _coreJoueur2.GetComponent<PlayerInput>().enabled = false;
        Debug.Log("Cinematic Sequence");
        EnablePlayersConstruction(false);
        DisablePlayersCores();
        DisablePlayersSpin();
        _cineCam.SetActive(true);
        _split.gameObject.SetActive(false);
        _inputManager.splitScreen = false;


        // Set Cam on player 1
        SetCineCamTarget(_zoneConstructionJoueur1.transform.position + new Vector3(_zoneSize, _zoneSize * .5f, _zoneSize) * .5f);
        SetCineCamTargetDistance(40, 30);
        EnablePlayerPhysics(1, true);
        _player1BaseImage.enabled = true;

        // Fade In noir
        float opacity = 1;
        while (opacity > 0)
        {
            opacity -= Time.deltaTime;
            _blackscreen.color = new Color(0, 0, 0, opacity);
            yield return null;
        }

        // Spin Cam around player 1
        float angle1 = 0;
        while (angle1 < 180)
        {
            angle1 += _cineCamRotationSpeed * Time.deltaTime;
            _cineCamTarget.transform.rotation = Quaternion.Euler(0, angle1, 0);
            yield return null;
        }

        // Fade Out noir
        while (opacity < 1)
        {
            opacity += Time.deltaTime * 2;
            _blackscreen.color = new Color(0, 0, 0, opacity);
            yield return null;
        }
        yield return new WaitForSeconds(_blackscreenDelay);

        // Set Cam on player 2
        SetCineCamTarget(_zoneConstructionJoueur2.transform.position + new Vector3(_zoneSize, _zoneSize * .5f, _zoneSize) * .5f);
        SetCineCamTargetDistance(40, 30);
        EnablePlayerPhysics(2, true);
        _cineCamTarget.transform.rotation = Quaternion.Euler(0, 0, 0);
        _player1BaseImage.enabled = false;
        _player2BaseImage.enabled = true;

        // Fade In noir
        while (opacity > 0)
        {
            opacity -= Time.deltaTime * 2;
            _blackscreen.color = new Color(0, 0, 0, opacity);
            yield return null;
        }

        // Spin Cam around player 2
        float angle2 = 0;
        while (angle2 < 180)
        {
            angle2 += _cineCamRotationSpeed * Time.deltaTime;
            _cineCamTarget.transform.rotation = Quaternion.Euler(0, angle2, 0);
            yield return null;
        }

        // Lerp Cam to Player 1 top camera
        while (_cineCamTarget.transform.position != (new Vector3(0, 0, 0) + new Vector3(_zoneSize, 0, _zoneSize) * .5f) && _cineCamTarget.transform.rotation != Quaternion.Euler(0, _cineCamAngleBeforeAttack, 0))
        {
            MoveCineCamTargetTo(new Vector3(0, 0, 0) + new Vector3(_zoneSize, 0, _zoneSize) * .5f);
            RotateCineCamTo(_cineCamAngleBeforeAttack);
            ChangeCineCamDistanceTo(30, 45);
            yield return null;
        }

        _player2BaseImage.enabled = false;
        _instructions.SetActive(true);

        StartCoroutine(MatchSequence());
    }

    IEnumerator MatchSequence()
    {
        Debug.Log("Match Sequence");
        EnablePlayersConstruction(false);
        DisablePlayersCores();
        DisablePlayersSpin();
        _inMatch = true;
        bool startTurn = false;
        float opacity = 0;

        _coreJoueur1.GetComponent<Core>().hasShot = true;
        _coreJoueur2.GetComponent<Core>().hasShot = true;

        while (!_player1CoreDestroyed && !_player2CoreDestroyed)
        {
            // Attendre Ready du spin de la base du joueur 1
            _turnPlayer1Image.enabled = true;
            EnablePlayerSpin(1);
            while (startTurn == false)
            {
                yield return new WaitUntil(() => PlayerManager.Instance.DonneesPersos[0].EstPret);
                startTurn = true;

                int seconds = 0;
                while (startTurn && seconds < 1)
                {
                    yield return new WaitForSeconds(1f);
                    seconds++;
                    if (!PlayerManager.Instance.DonneesPersos[0].EstPret) startTurn = false;
                }
            }
            DisablePlayersSpin();
            SetPlayerReady(0, false);
            startTurn = false;

            // CamTop joueur 1 à cam core joueur 1
            EnablePlayerCore(1);
            _zoneConstructionJoueur1.GetComponent<BuildingZone>().EnableFireMode();
            _coreJoueur1.GetComponent<Core>().ResetHasShot();
            Debug.Log("player 1 has shot : " + _coreJoueur1.GetComponent<Core>().hasShot);
            yield return new WaitUntil(() => _player1HasShot);
            yield return new WaitForSeconds(5);
            // _coreJoueur1.GetComponent<Core>().ResetHasShot();

            if(_player2CoreDestroyed) break;

            // Fade Out noir
            while (opacity < 1)
            {
                opacity += Time.deltaTime * 2;
                _blackscreen.color = new Color(0, 0, 0, opacity);
                yield return null;
            }
            yield return new WaitForSeconds(_blackscreenDelay);

            // Player 1 top camera
            DisablePlayersCores();
            SetCineCamTarget(new Vector3(0, 0, 0) + new Vector3(_zoneSize, 0, _zoneSize) * .5f);
            SetCineCamTargetDistance(30, 45);
            SetCineCamRotation(_cineCamAngleBeforeAttack);
            _zoneConstructionJoueur1.GetComponent<BuildingZone>().DisableFireMode();

            // Fade In noir
            while (opacity > 0)
            {
                opacity -= Time.deltaTime;
                _blackscreen.color = new Color(0, 0, 0, opacity);
                yield return null;
            }

            // Attendre Ready du spin de la base du joueur 1
            EnablePlayerSpin(1);
            while (startTurn == false)
            {
                yield return new WaitUntil(() => PlayerManager.Instance.DonneesPersos[0].EstPret);
                startTurn = true;

                int seconds = 0;
                while (startTurn && seconds < 1)
                {
                    yield return new WaitForSeconds(1f);
                    seconds++;
                    if (!PlayerManager.Instance.DonneesPersos[0].EstPret) startTurn = false;
                }
            }
            DisablePlayersSpin();
            SetPlayerReady(0, false);
            startTurn = false;

            // Fade Out noir
            while (opacity < 1)
            {
                opacity += Time.deltaTime * 2;
                _blackscreen.color = new Color(0, 0, 0, opacity);
                yield return null;
            }
            yield return new WaitForSeconds(_blackscreenDelay);

            _turnPlayer1Image.enabled = false;
            _turnPlayer2Image.enabled = true;

            // Player 2 top camera
            DisablePlayersCores();
            SetCineCamTarget(new Vector3(_distanceEntreZones, 0, 0) + new Vector3(_zoneSize, 0, _zoneSize) * .5f);
            SetCineCamTargetDistance(30, 45);
            SetCineCamRotation(_cineCamAngleBeforeAttack);

            // Fade In noir
            while (opacity > 0)
            {
                opacity -= Time.deltaTime;
                _blackscreen.color = new Color(0, 0, 0, opacity);
                yield return null;
            }

            // Attendre Ready du spin de la base du joueur 2
            EnablePlayerSpin(2);
            while (startTurn == false)
            {
                yield return new WaitUntil(() => PlayerManager.Instance.DonneesPersos[1].EstPret);
                startTurn = true;

                int seconds = 0;
                while (startTurn && seconds < 1)
                {
                    yield return new WaitForSeconds(1f);
                    seconds++;
                    if (!PlayerManager.Instance.DonneesPersos[1].EstPret) startTurn = false;
                }
            }
            DisablePlayersSpin();
            SetPlayerReady(1, false);
            startTurn = false;

            // CamTop joueur 2 à cam core joueur 2
            EnablePlayerCore(2);
            _zoneConstructionJoueur2.GetComponent<BuildingZone>().EnableFireMode();
            _coreJoueur2.GetComponent<Core>().ResetHasShot();
            Debug.Log("player 2 has shot : " + _coreJoueur2.GetComponent<Core>().hasShot);
            yield return new WaitUntil(() => _player2HasShot);
            yield return new WaitForSeconds(5);
            // _coreJoueur2.GetComponent<Core>().ResetHasShot();

            if(_player1CoreDestroyed) break;

            // Fade Out noir
            while (opacity < 1)
            {
                opacity += Time.deltaTime * 2;
                _blackscreen.color = new Color(0, 0, 0, opacity);
                yield return null;
            }
            yield return new WaitForSeconds(_blackscreenDelay);

            // Player 2 top camera
            DisablePlayersCores();
            SetCineCamTarget(new Vector3(_distanceEntreZones, 0, 0) + new Vector3(_zoneSize, 0, _zoneSize) * .5f);
            SetCineCamTargetDistance(30, 45);
            SetCineCamRotation(_cineCamAngleBeforeAttack);
            _zoneConstructionJoueur2.GetComponent<BuildingZone>().DisableFireMode();

            // Fade In noir
            while (opacity > 0)
            {
                opacity -= Time.deltaTime;
                _blackscreen.color = new Color(0, 0, 0, opacity);
                yield return null;
            }

            // Attendre Ready du spin de la base du joueur 2
            EnablePlayerSpin(2);
            while (startTurn == false)
            {
                yield return new WaitUntil(() => PlayerManager.Instance.DonneesPersos[1].EstPret);
                startTurn = true;

                int seconds = 0;
                while (startTurn && seconds < 1)
                {
                    yield return new WaitForSeconds(1f);
                    seconds++;
                    if (!PlayerManager.Instance.DonneesPersos[1].EstPret) startTurn = false;
                }
            }
            DisablePlayersSpin();
            SetPlayerReady(1, false);
            startTurn = false;

            // Fade Out noir
            while (opacity < 1)
            {
                opacity += Time.deltaTime * 2;
                _blackscreen.color = new Color(0, 0, 0, opacity);
                yield return null;
            }
            yield return new WaitForSeconds(_blackscreenDelay);

            _turnPlayer1Image.enabled = true;
            _turnPlayer2Image.enabled = false;

            // Player 1 top camera
            DisablePlayersCores();
            SetCineCamTarget(new Vector3(0, 0, 0) + new Vector3(_zoneSize, 0, _zoneSize) * .5f);
            SetCineCamTargetDistance(30, 45);
            SetCineCamRotation(_cineCamAngleBeforeAttack);

            // Fade In noir
            while (opacity > 0)
            {
                opacity -= Time.deltaTime;
                _blackscreen.color = new Color(0, 0, 0, opacity);
                yield return null;
            }
        }

        yield return new WaitForSeconds(3);
        SceneManager.LoadScene("MenuFin");
    }


    // Enables / Disables
    void EnablePlayerCore(int playerIndex)
    {
        switch (playerIndex)
        {
            case 1:
                _cameraCoreJoueur1.SetActive(true);
                _cameraCoreJoueur2.SetActive(false);
                _coreJoueur1.GetComponent<PlayerInput>().enabled = true;
                _coreJoueur2.GetComponent<PlayerInput>().enabled = true;
                // _coreJoueur2.GetComponent<PlayerInput>().enabled = false;
                break;
            case 2:
                _cameraCoreJoueur1.SetActive(false);
                _cameraCoreJoueur2.SetActive(true);
                _coreJoueur1.GetComponent<PlayerInput>().enabled = true;
                _coreJoueur2.GetComponent<PlayerInput>().enabled = true;
                // _coreJoueur1.GetComponent<PlayerInput>().enabled = false;
                break;
        }
        // _cameraCoreJoueur1.SetActive(true);
        // _coreJoueur1.GetComponent<PlayerInput>().enabled = true;
        // _cameraCoreJoueur2.SetActive(true);
        // _coreJoueur2.GetComponent<PlayerInput>().enabled = true;

        _cineCam.SetActive(false);
    }

    void DisablePlayersCores()
    {
        _cameraCoreJoueur1.SetActive(false);
        _cameraCoreJoueur2.SetActive(false);
        _coreJoueur1.GetComponent<PlayerInput>().enabled = false;
        _coreJoueur2.GetComponent<PlayerInput>().enabled = false;

        if (_inMatch) _cineCam.SetActive(true);
    }

    void EnablePlayersConstruction(bool enable)
    {
        switch (enable)
        {
            case true:
                _cameraConstructionJoueur1.SetActive(true);
                _cameraConstructionJoueur2.SetActive(true);
                _cameraConstructionJoueur1.GetComponent<PlayerInput>().enabled = true;
                _cameraConstructionJoueur2.GetComponent<PlayerInput>().enabled = true;
                break;
            case false:
                _cameraConstructionJoueur1.SetActive(false);
                _cameraConstructionJoueur2.SetActive(false);
                _cameraConstructionJoueur1.GetComponent<PlayerInput>().enabled = false;
                _cameraConstructionJoueur2.GetComponent<PlayerInput>().enabled = false;
                break;
        }
    }

    void EnablePlayerPhysics(int playerIndex, bool enable)
    {
        switch (playerIndex)
        {
            case 1:
                if (enable) _zoneConstructionJoueur1.GetComponent<BuildingZone>().DisableBuildMode();
                else _zoneConstructionJoueur1.GetComponent<BuildingZone>().EnableBuildMode();
                break;
            case 2:
                if (enable) _zoneConstructionJoueur2.GetComponent<BuildingZone>().DisableBuildMode();
                else _zoneConstructionJoueur2.GetComponent<BuildingZone>().EnableBuildMode();
                break;

        }
    }

    void EnablePlayerSpin(int playerIndex)
    {
        // switch (playerIndex)
        // {
        //     case 1:
        //         _zoneConstructionJoueur1.GetComponent<PlayerInput>().enabled = true;
        //         _zoneConstructionJoueur2.GetComponent<PlayerInput>().enabled = false;
        //         break;
        //     case 2:
        //         _zoneConstructionJoueur1.GetComponent<PlayerInput>().enabled = false;
        //         _zoneConstructionJoueur2.GetComponent<PlayerInput>().enabled = true;
        //         break;
        // }

        _zoneConstructionJoueur1.GetComponent<PlayerInput>().enabled = true;
        _zoneConstructionJoueur2.GetComponent<PlayerInput>().enabled = true;
    }

    void DisablePlayersSpin()
    {
        _zoneConstructionJoueur2.GetComponent<PlayerInput>().enabled = false;
        _zoneConstructionJoueur1.GetComponent<PlayerInput>().enabled = false;
    }


    // Camera Control
    void MoveCineCamTargetTo(Vector3 target)
    {
        _cineCamTarget.transform.position = Vector3.Lerp(_cineCamTarget.transform.position, target, _cineCamLerpSpeed * Time.deltaTime);
    }

    void RotateCineCamTo(int target)
    {
        _cineCamTarget.transform.rotation = Quaternion.Lerp(_cineCamTarget.transform.rotation, Quaternion.Euler(0, target, 0), _cineCamLerpSpeed * Time.deltaTime);
    }

    void ChangeCineCamDistanceTo(int distance, int angle)
    {
        float horizontal = distance * Mathf.Cos(angle * Mathf.Deg2Rad);
        float vertical = distance * Mathf.Sin(angle * Mathf.Deg2Rad);
        _cineCam.transform.localPosition = Vector3.Lerp(_cineCam.transform.localPosition, new Vector3(0, vertical, horizontal), _cineCamLerpSpeed * Time.deltaTime);
    }

    void SetCineCamTarget(Vector3 target)
    {
        _cineCamTarget.transform.position = target;
    }

    void SetCineCamTargetDistance(int distance, int angle)
    {
        float horizontal = distance * Mathf.Cos(angle * Mathf.Deg2Rad);
        float vertical = distance * Mathf.Sin(angle * Mathf.Deg2Rad);
        _cineCam.transform.localPosition = new Vector3(0, vertical, horizontal);
    }

    void SetCineCamRotation(int angle)
    {
        _cineCamTarget.transform.rotation = Quaternion.Euler(0, angle, 0);
    }
}
