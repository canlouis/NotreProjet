using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnchorPoint : MonoBehaviour
{
    [SerializeField] GameObject highlight;
    [SerializeField] GameObject Origin;
    BuildingZone BuildingZone;
    
    void Start()
    {
        highlight.SetActive(false);
        BuildingZone = GetComponentInParent<BuildingZone>();
    }

    
    void Update()
    {
        
    }

    public GameObject GetOrigin()
    {
        return Origin;
    }
}
