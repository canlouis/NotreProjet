using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

public class ConstructionCam : MonoBehaviour
{
    [Header("Références")]
    [SerializeField] GameObject _cubeFantome;
    [SerializeField] GameObject _block;
    [SerializeField] Image[] _inventaire;
    [SerializeField] TextMeshProUGUI _textePret;

    [Header("Caméra")]
    [SerializeField] float _sensibiliteSouris = 1;
    [SerializeField] float _sensibiliteManette = 1;
    float _sensibilite;
    Camera _cam;
    InputAction _regarder;
    float _rotationX = 0;
    float _rotationY = 0;
    Vector2 _tournerCam;

    [Header("Déplacement")]
    [SerializeField] float _vitesseHorizontale = 1;
    [SerializeField] float _vitesseVerticale = 1;
    Vector2 _deplacement;
    InputAction _monter;
    InputAction _descendre;
    InputAction _deplacer;
    Vector3 _directionDeplacement;
    Vector3 _deplacementVertical;
    bool _aPoseCore = false;
    private float _tempsEcouleUpdate = 0f;
    private float _intervalleUpdate = 0.1f; // 100ms
    Vector3 _posCubeFantome;
    Vector3 _directionActuelle = Vector3.zero;
    GameObject _cubeActuel;
    GameObject _cubeFantomeInstancie;
    CharacterController _controller;
    PlayerInput _playerInput;
    bool _cubeFantomeEstInstancie = false;
    [SerializeField] BuildingZone _buildingZone;
    public BuildingZone buildingZone => _buildingZone;
    [SerializeField] GameObject _core;
    int _selectedBlock = 0;
    List<CubesType> _cubesType;
    GameObject _blocActuel;
    DonneesPerso _donneesPerso;

    // Start is called before the first frame update
    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;

        _cam = GetComponent<Camera>();
        _controller = GetComponent<CharacterController>();

        _playerInput = GetComponent<PlayerInput>();
        _cubesType = PlayerManager.Instance.DonneesPersos[_playerInput.playerIndex].Cubes;

        _regarder = _playerInput.actions["Look"];
        _deplacer = _playerInput.actions["Move"];
        _monter = _playerInput.actions["Monter"];
        _descendre = _playerInput.actions["Descendre"];

        _regarder.performed += ctx => _tournerCam = ctx.ReadValue<Vector2>();
        _regarder.canceled += _ => _tournerCam = Vector2.zero;
        _deplacer.performed += ctx => _deplacement = ctx.ReadValue<Vector2>();
        _deplacer.canceled += _ => _deplacement = Vector2.zero;
        _monter.performed += _ => _deplacementVertical = Vector3.up * _vitesseVerticale;
        _monter.canceled += _ => _deplacementVertical.y = 0;
        _descendre.performed += _ => _deplacementVertical = Vector3.down * _vitesseVerticale;
        _descendre.canceled += _ => _deplacementVertical.y = 0;

        _donneesPerso = PlayerManager.Instance.DonneesPersos[_playerInput.playerIndex];


        // Instancie le cube fantôme une fois et désactive-le
        _cubeFantomeInstancie = Instantiate(_cubeFantome);
        _cubeFantomeInstancie.SetActive(false);

        // Initialiser la sensibilité en appelant ChangerSensibilite immédiatement
        OnControlsChanged(_playerInput);

        StartCoroutine(InitInventaire());

    }

    IEnumerator InitInventaire()
    {
        yield return new WaitForSeconds(.1f);

        for (int i = 0; i < _cubesType.Count; i++)
        {
            CubesType cube = _cubesType[i];
            _inventaire[i].GetComponentInChildren<TextMeshProUGUI>().text = cube.NbCubesRestant.ToString();
            _inventaire[i].color = cube.CubeCouleur;
        }
        _inventaire[_selectedBlock].rectTransform.localScale = new Vector3(1.2f, 1.2f, 1.2f);
        _inventaire[_selectedBlock].transform.SetAsLastSibling();

        _textePret.text = _donneesPerso.EstPret ? "Prêt" : "Non prêt";
        _textePret.color = _donneesPerso.EstPret ? Color.white : Color.gray;
        _textePret.fontSize = _donneesPerso.EstPret ? 80 : 40;
    }

    private void GestionRegarder()
    {
        // Calculer les mouvements de la souris ou du stick
        float sourisX = _tournerCam.x * _sensibilite * Time.deltaTime;
        float sourisY = _tournerCam.y * _sensibilite * Time.deltaTime;

        // Rotation verticale (caméra)
        _rotationX -= sourisY;
        _rotationY += sourisX;
        _rotationX = Mathf.Clamp(_rotationX, -90f, 90f);
        transform.localRotation = Quaternion.Euler(_rotationX, _rotationY, 0f);
    }

    void OnControlsChanged(PlayerInput playerInput)
    {
        // Vérifier le schéma de contrôle actif et définir la vitesse appropriée
        if (playerInput.currentControlScheme == "Gamepad")
        {
            _sensibilite = _sensibiliteManette;
        }
        else
        {
            _sensibilite = _sensibiliteSouris;
        }
    }

    void GestionMouvement()
    {
        Vector2 _deplacementHorizontal = new Vector2(_deplacement.x, _deplacement.y) * _vitesseHorizontale;
        _directionDeplacement = transform.right * _deplacementHorizontal.x + transform.forward * _deplacementHorizontal.y + _deplacementVertical;
        _controller.Move(_directionDeplacement * Time.deltaTime);
    }

    // Update is called once per frame
    void Update()
    {
        GestionRegarder();
        GestionMouvement();

        if (Time.time >= _tempsEcouleUpdate && _buildingZone.enableBuildMode && !_donneesPerso.EstPret)
        {
            _tempsEcouleUpdate = Time.time + _intervalleUpdate;


            Ray ray = _cam.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0));
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit, LayerMask.GetMask("Cube")))
            {
                Vector3 point = hit.point;
                _cubeActuel = hit.transform.gameObject;

                if (_cubeActuel.tag == "AnchorPoint")
                {
                    _posCubeFantome = _cubeActuel.GetComponent<AnchorPoint>().GetOrigin().transform.position;
                    _directionActuelle = Vector3.zero;

                    // Active et déplace le cube fantôme si nécessaire
                    if (!_cubeFantomeEstInstancie)
                    {
                        _cubeFantomeInstancie.SetActive(true);
                        _cubeFantomeEstInstancie = true;
                    }
                    _cubeFantomeInstancie.transform.position = _posCubeFantome;
                }
                else if (_cubeActuel.tag == "Block")
                {
                    // _blocActuel = _cubeActuel.GetComponent<Block>();
                    // _cubeActuel = _cubeActuel.GetComponent<Block>().GetOrigin();
                    _blocActuel = _cubeActuel;
                    if (_cubeActuel.GetComponent<Block>())
                    {
                        _cubeActuel = _cubeActuel.GetComponent<Block>().GetOrigin();
                    }
                    else if (_cubeActuel.GetComponent<Core>())
                    {
                        _cubeActuel = _cubeActuel.GetComponent<Core>().GetOrigin();
                    }

                    Vector3 difference = point - _cubeActuel.transform.position;

                    if (Mathf.Abs(difference.x) > Mathf.Abs(difference.y) && Mathf.Abs(difference.x) > Mathf.Abs(difference.z))
                    {
                        _directionActuelle = difference.x > 0 ? Vector3.right : Vector3.left;
                    }
                    else if (Mathf.Abs(difference.y) > Mathf.Abs(difference.x) && Mathf.Abs(difference.y) > Mathf.Abs(difference.z))
                    {
                        _directionActuelle = difference.y > 0 ? Vector3.up : Vector3.down;
                    }
                    else
                    {
                        _directionActuelle = difference.z > 0 ? Vector3.forward : Vector3.back;
                    }

                    // Active et déplace le cube fantôme si nécessaire
                    _posCubeFantome = hit.transform.position + _directionActuelle;
                    if (!_cubeFantomeEstInstancie)
                    {
                        _cubeFantomeInstancie.SetActive(true);
                        _cubeFantomeEstInstancie = true;
                    }
                    _cubeFantomeInstancie.transform.position = _posCubeFantome;
                }
            }
            else if (_cubeFantomeInstancie.activeSelf)
            {
                // Désactive le cube fantôme si aucune position valide n'est trouvée
                _cubeFantomeInstancie.SetActive(false);
                _cubeFantomeEstInstancie = false;
            }
        }
    }

    void OnDisable()
    {
        if (_cubeFantomeInstancie != null)
        {
            _cubeFantomeInstancie.SetActive(false);
            _cubeFantomeEstInstancie = false;
        }
    }

    void OnRetirerCube()
    {
        if (_blocActuel != null && _buildingZone.enableBuildMode && !_donneesPerso.EstPret)
        {
            SoundManager.instance.PlaySFX(EnumSFX.RetirerCube, null); // Jouer le son du bouton
            if (_blocActuel.GetComponent<Block>())
            {
                _buildingZone.Blocks.Remove(_blocActuel.GetComponent<Block>());
            int index = 0;
            for (int i = 0; i < _cubesType.Count; i++)
            {
                    if (_cubesType[i].Type == _blocActuel.GetComponent<Block>().type)
                {
                    break;
                }
                index++;
            }
            _cubesType[index].NbCubesRestant++;
            _inventaire[index].GetComponentInChildren<TextMeshProUGUI>().text = _cubesType[index].NbCubesRestant.ToString();
            }
            else if (_blocActuel.GetComponent<Core>())
            {
                _aPoseCore = false;
                _cubesType[_cubesType.Count - 1].NbCubesRestant++;
                _inventaire[_cubesType.Count - 1].GetComponentInChildren<TextMeshProUGUI>().text = _cubesType[_cubesType.Count - 1].NbCubesRestant.ToString();
            }

            _cubeFantomeInstancie.SetActive(false);
            _cubeFantomeEstInstancie = false;
            Destroy(_blocActuel.gameObject);
            _blocActuel = null;
        }
    }

    void BlockSelect(int index)
    {
        _inventaire[_selectedBlock].rectTransform.localScale = new Vector3(1, 1, 1);

        _selectedBlock += index;
        if (_selectedBlock < 0)
        {
            _selectedBlock = _cubesType.Count - 1;
        }
        else if (_selectedBlock >= _cubesType.Count)
        {
            _selectedBlock = 0;
        }

        _inventaire[_selectedBlock].rectTransform.localScale = new Vector3(1.2f, 1.2f, 1.2f);
        _inventaire[_selectedBlock].transform.SetAsLastSibling();
    }

    void OnFire()
    {
        if (_cubeFantomeEstInstancie && _buildingZone.enableBuildMode && !_donneesPerso.EstPret)
        {
            SoundManager.instance.PlaySFX(EnumSFX.PlacerCube, null); // Jouer le son du bouton
            if (_cubesType[_selectedBlock].NbCubesRestant > 0)
            {
                if (_cubesType[_selectedBlock].Type == CubesType.BlockType.Core)
                {
                    _buildingZone.PlaceCube(_cubeFantomeInstancie.transform, _core, _playerInput.playerIndex, _selectedBlock);
                    _aPoseCore = true;
                }
                else
                {
                    _buildingZone.PlaceCube(_cubeFantomeInstancie.transform, _block.gameObject, _playerInput.playerIndex, _selectedBlock);
                }
                _cubesType[_selectedBlock].NbCubesRestant--;
                _inventaire[_selectedBlock].GetComponentInChildren<TextMeshProUGUI>().text = _cubesType[_selectedBlock].NbCubesRestant.ToString();
            }
            else
            {
                Color color = _inventaire[_selectedBlock].color;
                _inventaire[_selectedBlock].color = new Color(color.r, color.g, color.b, 0.5f);
            }

            _cubeFantomeInstancie.SetActive(false);
            _cubeFantomeEstInstancie = false;
        }
    }

    IEnumerator ChangerTextePret()
    {
        yield return new WaitForSeconds(3);
        _textePret.text = _donneesPerso.EstPret ? "Prêt" : "Non prêt";
        _textePret.color = _donneesPerso.EstPret ? _donneesPerso.Couleur : Color.gray;
        _textePret.fontSize = _donneesPerso.EstPret ? 80 : 40;
    }

    void OnPret()
    {
        SoundManager.instance.PlaySFX(EnumSFX.bouton, null); // Jouer le son du bouton
        _donneesPerso.EstPret = !_donneesPerso.EstPret;
        if (_donneesPerso.EstPret && !_aPoseCore)
        {
            _donneesPerso.EstPret = false;
            _textePret.text = "Le noyaux n'a pas été posé";
            _textePret.color = Color.red;
            StartCoroutine(ChangerTextePret());
        }
        else
        {
            _cubeFantomeInstancie.SetActive(false);
            _cubeFantomeEstInstancie = false;
            _textePret.text = _donneesPerso.EstPret ? "Prêt" : "Non prêt";
            _textePret.color = _donneesPerso.EstPret ? _donneesPerso.Couleur : Color.gray;
            _textePret.fontSize = _donneesPerso.EstPret ? 80 : 40;
        }
    }

    void OnTabRight()
    {
        SoundManager.instance.PlaySFX(EnumSFX.bouton, null); // Jouer le son du bouton
        BlockSelect(1);
    }

    void OnTabLeft()
    {
        SoundManager.instance.PlaySFX(EnumSFX.bouton, null); // Jouer le son du bouton
        BlockSelect(-1);
    }
}